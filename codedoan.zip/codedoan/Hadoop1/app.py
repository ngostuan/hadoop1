from flask import Flask,  render_template, jsonify, request, Response
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

def generate(command):
    try:
        # Thực thi lệnh với subprocess
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )

        # Đọc stdout và gửi kết quả từng dòng qua SSE
        for line in iter(process.stdout.readline, ''):
            yield f"data: {line}\n\n"  # Trả về dòng dữ liệu

        # Đọc stderr (nếu có) và gửi lỗi
        for line in iter(process.stderr.readline, ''):
            yield f"data: {line}\n\n"  # Trả về lỗi nếu có

        process.stdout.close()
        process.stderr.close()
        process.wait()

    except Exception as e:
        yield f"data: Error: {str(e)}\n\n"

@app.route('/run_command', methods=['GET'])
def run_command():
    # Lấy lệnh từ query parameters
    command_map = {
        'cat_file1': 'cat 336.txt',
        'cat_file2': 'cat file2.txt',
        'cat_file3': 'cat file3.txt',
        'run_script': 'bash ../Hadoop3/start.sh'
    }

    command = request.args.get('command')
    
    if command not in command_map:
        return Response("Invalid command", status=400)

    # Sử dụng SSE (Server-Sent Events) để gửi dữ liệu liên tục
    return Response(generate(command_map[command]), content_type='text/event-stream')
def stream_commands():
    commands = [
        ("Đang thu thập dữ liệu và đẩy lên hệ thống:", [
            'tshark', '-a', 'duration:50', '-Y', 'not ip.src == 192.168.82.128',
            '|', 'hadoop', 'fs', '-put', '-', '/tshark0'
        ]),
        ("Đang xử lý và tính toán dữ liệu:", [
            '/usr/local/hadoop/bin/hadoop', 
            'jar', '/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.3.6.jar',
            '-mapper', '/home/hadoop/codedoan/Hadoop2/mappper.py',
            '-reducer', '/home/hadoop/codedoan/Hadoop2/redufull.py',
            '-input', '/tshark0',
            '-output', '/user/output1'
        ]),
      
        ("Danh sách tính toán entropy của log:", [
            'hadoop', 'fs', '-cat', '/user/output1/part-00000'
        ]),
    ]

    for index, (description, command) in enumerate(commands):
        yield f"<p>{description}</p>"
        try:
            if index == len(commands) - 1:  # Nếu là lệnh cuối, hiển thị output
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                for line in iter(process.stdout.readline, ''):
                    yield f"<p>{line.strip()}</p>"
                process.stdout.close()
                process.wait()
                if process.returncode != 0:
                    yield f"<p>Error: {process.stderr.read().strip()}</p>"
            else:
                # Chạy các lệnh không cần hiển thị output
                subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        except subprocess.CalledProcessError as e:
            yield f"<p>Error: {e.stderr.strip()}</p>"

# Route to run commands and stream the output
@app.route('/run_commands')
def run_commands():
    return Response(stream_commands(), content_type='text/html')
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

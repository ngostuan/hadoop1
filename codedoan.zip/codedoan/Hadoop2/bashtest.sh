#!/bin/bash  
tshark -a duration:50 -Y "not ip.src == 192.168.82.128" | hadoop fs -put - /tshark0
/usr/local/hadoop/bin/hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.3.6.jar  -mapper /home/hadoop/m2.py -reducer /home/hadoop/r47.py -input /tshark0 -output /user/output1
hadoop fs -cat /user/output1/part-00000 
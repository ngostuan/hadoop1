import requests
import threading

# Địa chỉ IP cục bộ và cổng của server
TARGET_IP = "http://192.168.82.128"
REQUEST_COUNT = 100000  # Số lượng yêu cầu mỗi luồng
THREAD_COUNT = 10    # Số lượng luồng

def send_requests():
    for _ in range(REQUEST_COUNT):
        try:
            response = requests.get(TARGET_IP)
            print(f"Response: {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"Request failed: {e}")

# Tạo và khởi chạy nhiều luồng
threads = []
for _ in range(THREAD_COUNT):
    thread = threading.Thread(target=send_requests)
    threads.append(thread)
    thread.start()

# Chờ tất cả các luồng hoàn thành
for thread in threads:
    thread.join()

print("Load test completed.")

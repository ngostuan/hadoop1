#!/usr/bin/python3
import sys

# Đếm số lần xuất hiện của từng IP
for line in sys.stdin:
    line = line.strip()
    
    # Giả sử IP xuất hiện ở cột thứ 3, tách các cột từ dòng log
    columns = line.split()
    
    # Nếu có đủ cột để trích xuất IP (cột thứ 3)
    if len(columns) > 2:
        ip = columns[2]
        print(f"{ip}\t1")

#!/usr/bin/python3
"""reducer.py"""
import sys
import math
import pandas as pd

# Khởi tạo từ điển lưu trữ số lần xuất hiện của mỗi IP
ip_count = {}
total_packets = 0

# Đếm số lần xuất hiện của từng IP
for line in sys.stdin:
    line = line.strip()
    ip = line.split()[0]  
    ip_count[ip] = ip_count.get(ip, 0) + 1
    total_packets += 1

# Tính entropy
entropy = 0
rows = []
for ip, count in ip_count.items():
    prob = count / total_packets
    entropy -= prob * math.log(prob, 2)
    rows.append([ip, count, prob, prob * math.log(prob, 2)])

# Tạo bảng từ dữ liệu
df = pd.DataFrame(rows, columns=["IP Address", "Count", "Probability", "p(x) * log2(p(x))"])

# In ra tất cả các IP và probability của chúng
for index, row in df.iterrows():
    print(f"{row['IP Address']} {row['Probability']}")
